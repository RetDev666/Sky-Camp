// js/theme.js
// Runs early to prevent flash of unstyled content
(function() {
  const saved = localStorage.getItem('skycamp-theme');
  const isDark = saved === 'dark' || (!saved && window.matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.setAttribute('data-theme', isDark ? 'dark' : 'light');
})();

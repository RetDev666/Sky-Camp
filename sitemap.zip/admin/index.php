<?php
require_once 'includes/db.php';
require_once 'includes/auth.php';
requireLogin();

// Обробка зміни статусу
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['id'])) {
    $id = (int)$_POST['id'];
    $newStatus = $_POST['status'] === 'Нова' ? 'Оброблена' : 'Нова';
    
    if ($_POST['action'] === 'toggle_booking') {
        $stmt = $db->prepare("UPDATE bookings SET status = ? WHERE id = ?");
        $stmt->execute([$newStatus, $id]);
    } elseif ($_POST['action'] === 'toggle_message') {
        $stmt = $db->prepare("UPDATE messages SET status = ? WHERE id = ?");
        $stmt->execute([$newStatus, $id]);
    }
    header('Location: index.php');
    exit;
}

// Отримання бронювань
$bookings = $db->query("SELECT * FROM bookings ORDER BY created_at DESC")->fetchAll();
// Отримання повідомлень
$messages = $db->query("SELECT * FROM messages ORDER BY created_at DESC")->fetchAll();

require 'includes/header.php';
?>

<div class="admin-header">
    <h1 class="text-h2">Панель управління заявами</h1>
    <div>Вітаємо, <b><?= htmlspecialchars($_SESSION['admin_username']) ?></b>!</div>
</div>

<div class="admin-card">
    <h2 class="text-h3" style="margin-bottom:var(--space-md);">Заявки на бронювання</h2>
    <?php if (count($bookings) > 0): ?>
    <table class="admin-table">
        <thead>
            <tr>
                <th>Дата</th>
                <th>Дитина</th>
                <th>Батьки / Контакти</th>
                <th>Програма</th>
                <th>Статус</th>
                <th>Дія</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($bookings as $b): ?>
            <tr>
                <td><?= date('d.m.Y H:i', strtotime($b['created_at'])) ?></td>
                <td><?= htmlspecialchars($b['child_name']) ?> (<?= $b['child_age'] ?> р.)</td>
                <td>
                    <?= htmlspecialchars($b['parent_name']) ?><br>
                    <a href="tel:<?= htmlspecialchars($b['phone']) ?>"><?= htmlspecialchars($b['phone']) ?></a><br>
                    <a href="mailto:<?= htmlspecialchars($b['email']) ?>"><?= htmlspecialchars($b['email']) ?></a>
                </td>
                <td><?= htmlspecialchars($b['program']) ?> (<?= htmlspecialchars($b['date']) ?>)</td>
                <td>
                    <span class="badge <?= $b['status'] === 'Нова' ? 'badge-superadmin' : 'badge-admin' ?>">
                        <?= htmlspecialchars($b['status']) ?>
                    </span>
                </td>
                <td>
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="action" value="toggle_booking">
                        <input type="hidden" name="id" value="<?= $b['id'] ?>">
                        <input type="hidden" name="status" value="<?= $b['status'] ?>">
                        <button type="submit" class="btn btn-sm <?= $b['status'] === 'Нова' ? 'btn-primary' : 'btn-outline' ?>">
                            <?= $b['status'] === 'Нова' ? 'Позначити обробленою' : 'Повернути в Нові' ?>
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: ?>
        <p>Заявок на бронювання поки немає.</p>
    <?php endif; ?>
</div>

<div class="admin-card">
    <h2 class="text-h3" style="margin-bottom:var(--space-md);">Контактні повідомлення</h2>
    <?php if (count($messages) > 0): ?>
    <table class="admin-table">
        <thead>
            <tr>
                <th>Дата</th>
                <th>Ім'я</th>
                <th>Email</th>
                <th>Повідомлення</th>
                <th>Статус</th>
                <th>Дія</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($messages as $m): ?>
            <tr>
                <td><?= date('d.m.Y H:i', strtotime($m['created_at'])) ?></td>
                <td><?= htmlspecialchars($m['name']) ?></td>
                <td><a href="mailto:<?= htmlspecialchars($m['email']) ?>"><?= htmlspecialchars($m['email']) ?></a></td>
                <td><?= nl2br(htmlspecialchars($m['message'])) ?></td>
                <td>
                    <span class="badge <?= $m['status'] === 'Нова' ? 'badge-superadmin' : 'badge-admin' ?>">
                        <?= htmlspecialchars($m['status']) ?>
                    </span>
                </td>
                <td>
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="action" value="toggle_message">
                        <input type="hidden" name="id" value="<?= $m['id'] ?>">
                        <input type="hidden" name="status" value="<?= $m['status'] ?>">
                        <button type="submit" class="btn btn-sm <?= $m['status'] === 'Нова' ? 'btn-primary' : 'btn-outline' ?>">
                            <?= $m['status'] === 'Нова' ? 'Позначити обробленим' : 'Повернути в Нові' ?>
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: ?>
        <p>Повідомлень поки немає.</p>
    <?php endif; ?>
</div>

<?php require 'includes/footer.php'; ?>

<?php
require_once 'includes/db.php';
require_once 'includes/auth.php';
requireSuperadmin();

$error = '';
$success = '';

// Додавання користувача
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] === 'superadmin' ? 'superadmin' : 'admin';

    if ($username && $password) {
        $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetchColumn() > 0) {
            $error = 'Користувач з таким логіном вже існує!';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $db->prepare("INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)");
            if ($stmt->execute([$username, $hash, $role])) {
                $success = 'Адміністратора успішно створено!';
            } else {
                $error = 'Помилка при створенні адміністратора.';
            }
        }
    } else {
        $error = 'Заповніть всі поля!';
    }
}

// Видалення користувача
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    if ($id !== $_SESSION['admin_id']) { // Не можна видалити самого себе
        $stmt = $db->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$id]);
        $success = 'Адміністратора видалено.';
    } else {
        $error = 'Ви не можете видалити власний акаунт.';
    }
}

$users = $db->query("SELECT id, username, role, created_at FROM users ORDER BY created_at DESC")->fetchAll();

require 'includes/header.php';
?>

<div class="admin-header">
    <h1 class="text-h2">Управління адміністраторами</h1>
</div>

<?php if ($error): ?>
    <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>
<?php if ($success): ?>
    <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<div style="display:flex; gap: var(--space-xl); align-items: flex-start;">
    
    <div class="admin-card" style="flex:1;">
        <h2 class="text-h3" style="margin-bottom:var(--space-md);">Список адміністраторів</h2>
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Логін</th>
                    <th>Роль</th>
                    <th>Створено</th>
                    <th>Дії</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($users as $u): ?>
                <tr>
                    <td><b><?= htmlspecialchars($u['username']) ?></b></td>
                    <td>
                        <span class="badge <?= $u['role'] === 'superadmin' ? 'badge-superadmin' : 'badge-admin' ?>">
                            <?= $u['role'] ?>
                        </span>
                    </td>
                    <td><?= date('d.m.Y', strtotime($u['created_at'])) ?></td>
                    <td class="action-links">
                        <?php if ($u['id'] !== $_SESSION['admin_id']): ?>
                        <a href="users.php?delete=<?= $u['id'] ?>" class="delete" onclick="return confirm('Ви впевнені, що хочете видалити цього користувача?');">Видалити</a>
                        <?php else: ?>
                        <span style="color:var(--on-surface-variant);font-size:0.9rem;">(Це ви)</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="admin-card" style="width: 350px;">
        <h2 class="text-h3" style="margin-bottom:var(--space-md);">Додати нового</h2>
        <form method="post" action="users.php">
            <input type="hidden" name="action" value="add">
            <div class="form-group">
                <label for="username">Логін</label>
                <input type="text" id="username" name="username" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="password">Пароль</label>
                <input type="password" id="password" name="password" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="role">Роль</label>
                <select id="role" name="role" class="form-control">
                    <option value="admin">Звичайний Адмін (тільки перегляд заявок)</option>
                    <option value="superadmin">Суперадмін (може додавати інших)</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary w-100">Створити адміністратора</button>
        </form>
    </div>

</div>

<?php require 'includes/footer.php'; ?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sky Camp - Адмін-панель</title>
    <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@400;500;600&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/global.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body class="admin-body">
    <?php if(isLoggedIn()): ?>
    <aside class="admin-sidebar">
        <div class="admin-logo">Sky Camp Admin</div>
        <nav class="admin-nav">
            <a href="index.php" class="<?= basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : '' ?>">
                <span class="material-symbols-outlined">dashboard</span> Заявки
            </a>
            <?php if(isSuperadmin()): ?>
            <a href="users.php" class="<?= basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : '' ?>">
                <span class="material-symbols-outlined">group</span> Адміністратори
            </a>
            <?php endif; ?>
            <a href="logout.php">
                <span class="material-symbols-outlined">logout</span> Вихід
            </a>
        </nav>
    </aside>
    <main class="admin-main">
    <?php endif; ?>

<?php
// Підключення до бази даних SQLite
$dbFile = __DIR__ . '/../db/skycamp.sqlite';
$dsn = 'sqlite:' . $dbFile;

try {
    $db = new PDO($dsn);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Помилка підключення до бази даних: " . $e->getMessage());
}
?>

<?php
session_start();

function isLoggedIn() {
    return isset($_SESSION['admin_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

function isSuperadmin() {
    return isset($_SESSION['admin_role']) && $_SESSION['admin_role'] === 'superadmin';
}

function requireSuperadmin() {
    requireLogin();
    if (!isSuperadmin()) {
        die("Помилка: У вас немає прав для перегляду цієї сторінки.");
    }
}
?>

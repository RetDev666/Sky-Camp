<?php
require_once 'includes/db.php';

// Створення таблиць
$sql = "
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'admin',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    child_name TEXT,
    child_age INTEGER,
    parent_name TEXT,
    phone TEXT,
    email TEXT,
    program TEXT,
    date TEXT,
    status TEXT DEFAULT 'Нова',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    email TEXT,
    message TEXT,
    status TEXT DEFAULT 'Нова',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
";

$db->exec($sql);

// Створення першого суперадміна, якщо таблиця порожня
$stmt = $db->query("SELECT COUNT(*) FROM users");
$count = $stmt->fetchColumn();

if ($count == 0) {
    $defaultUser = 'admin';
    $defaultPass = 'admin123';
    $hash = password_hash($defaultPass, PASSWORD_DEFAULT);
    
    $stmt = $db->prepare("INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'superadmin')");
    $stmt->execute([$defaultUser, $hash]);
    
    echo "<h1>База даних успішно створена!</h1>";
    echo "<p>Створено Головного адміністратора:</p>";
    echo "<ul><li>Логін: <b>$defaultUser</b></li><li>Пароль: <b>$defaultPass</b></li></ul>";
    echo "<p style='color:red;'><b>УВАГА:</b> Обов'язково видаліть файл <code>setup.php</code> після завершення налаштування!</p>";
    echo "<a href='login.php'>Перейти до сторінки входу</a>";
} else {
    echo "<h1>База даних вже ініціалізована.</h1>";
    echo "<a href='login.php'>Перейти до сторінки входу</a>";
}
?>

<?php
/**
 * Sky Camp вЂ” PHP Form Handler
 * РћР±СЂРѕР±Р»СЏС” Р·Р°СЏРІРєРё Р· С„РѕСЂРјРё Р±СЂРѕРЅСЋРІР°РЅРЅСЏ С‚Р° РєРѕРЅС‚Р°РєС‚РЅРѕС— С„РѕСЂРјРё
 * РќР°РґСЃРёР»Р°С” email-СЃРїРѕРІС–С‰РµРЅРЅСЏ РЅР° РїРѕС€С‚Сѓ Р°РґРјС–РЅС–СЃС‚СЂР°С‚РѕСЂР°
 *
 * РќР°Р»Р°С€С‚СѓРІР°РЅРЅСЏ: Р·РјС–РЅС–С‚СЊ ADMIN_EMAIL РЅР° РІР°С€Сѓ РїРѕС€С‚Сѓ
 */

// ── РљРѕРЅС„С–РіСѓСЂР°С†С–СЏ ────────────────────────────────────────────────────────────
define('ADMIN_EMAIL', 'info@sky-camp.pp.ua');       // ← замініть на вашу пошту
define('SITE_NAME',   'Sky Camp');
define('SITE_URL',    'https://sky-camp.pp.ua');
define('ALLOWED_ORIGIN', 'https://sky-camp.pp.ua'); // ← ваш домен

// ── CORS С‚Р° Р·Р°РіРѕР»РѕРІРєРё ──────────────────────────────────────────────────────
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
// Р”РѕР·РІРѕР»СЏС”РјРѕ С‚Р°РєРѕР¶ localhost РґР»СЏ СЂРѕР·СЂРѕР±РєРё
if ($origin === ALLOWED_ORIGIN || preg_match('/^https?:\/\/localhost(:\d+)?$/', $origin)) {
    header('Access-Control-Allow-Origin: ' . $origin);
}
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// ── РўС–Р»СЊРєРё POST ──────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

// ── Rate limiting (РїСЂРѕСЃС‚РёР№ С‡РµСЂРµР· СЃРµСЃС–СЋ) ──────────────────────────
session_start();
$now = time();
if (!isset($_SESSION['form_last_submit'])) {
    $_SESSION['form_last_submit'] = 0;
    $_SESSION['form_count'] = 0;
}
// РќРµ Р±С–Р»СЊС€Рµ 5 РІС–РґРїСЂР°РІРѕРє Р·Р° 10 С…РІРёР»РёРЅ
if ($now - $_SESSION['form_last_submit'] < 600) {
    $_SESSION['form_count']++;
    if ($_SESSION['form_count'] > 5) {
        http_response_code(429);
        echo json_encode(['ok' => false, 'error' => 'Р—Р°Р±Р°РіР°С‚Рѕ Р·Р°РїРёС‚С–РІ. РЎРїСЂРѕР±СѓР№С‚Рµ РїС–Р·РЅС–С€Рµ.']);
        exit;
    }
} else {
    $_SESSION['form_count'] = 1;
    $_SESSION['form_last_submit'] = $now;
}

// ── Р§РёС‚Р°С”РјРѕ JSON ─────────────────────────────────────────────────────────────
$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!$data || !isset($data['type'])) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'РќРµРІС–СЂРЅРёР№ С„РѕСЂРјР°С‚ РґР°РЅРёС…']);
    exit;
}

// ── РЎР°РЅС–С‚РёР·Р°С†С–СЏ ────────────────────────────────────────────────────────────
function clean(string $str): string {
    return htmlspecialchars(strip_tags(trim($str)), ENT_QUOTES, 'UTF-8');
}

// ── РњР°СЂС€СЂСѓС‚РёР·Р°С†С–СЏ ────────────────────────────────────────────────────────
$type = $data['type'] ?? '';

if ($type === 'booking') {
    handleBooking($data);
} elseif ($type === 'contact') {
    handleContact($data);
} else {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'РќРµРІС–РґРѕРјРёР№ С‚РёРї С„РѕСЂРјРё']);
    exit;
}

// ── Відправка в Telegram ──
require_once __DIR__ . '/admin/includes/telegram.php';

// ════════════════════════════════════════════════════════════════════════════
// БРОНЮВАННЯ
// ════════════════════════════════════════════════════════════════════════════
function handleBooking(array $d): void {
    // Р’Р°Р»С–РґР°С†С–СЏ РѕР±РѕРІ'СЏР·РєРѕРІРёС… РїРѕР»С–РІ
    $required = ['child_first', 'child_last', 'child_dob', 'parent_name', 'parent_email', 'parent_phone', 'program'];
    foreach ($required as $field) {
        if (empty($d[$field])) {
            http_response_code(422);
            echo json_encode(['ok' => false, 'error' => "РџРѕР»Рµ '$field' С” РѕР±РѕРІ'СЏР·РєРѕРІРёРј"]);
            exit;
        }
    }

    if (!filter_var($d['parent_email'], FILTER_VALIDATE_EMAIL)) {
        http_response_code(422);
        echo json_encode(['ok' => false, 'error' => 'РќРµРІС–СЂРЅРёР№ С„РѕСЂРјР°С‚ email']);
        exit;
    }

    // Р“РµРЅРµСЂР°С†С–СЏ РЅРѕРјРµСЂР° Р·Р°СЏРІРєРё
    $bookingId = 'SKY-2026-' . strtoupper(substr(md5(uniqid('', true)), 0, 6));

    // Р¤РѕСЂРјСѓС”РјРѕ email
    $childName   = clean($d['child_first']) . ' ' . clean($d['child_last']);
    $program     = clean($d['program']);
    $dates       = clean($d['dates'] ?? 'вЂ”');
    $price       = clean($d['price'] ?? 'вЂ”');
    $parentName  = clean($d['parent_name']);
    $parentEmail = clean($d['parent_email']);
    $parentPhone = clean($d['parent_phone']);
    $parentPhone2= clean($d['parent_phone2'] ?? 'вЂ”');
    $childDob    = clean($d['child_dob'] ?? 'вЂ”');
    $childAge    = clean($d['child_age'] ?? 'вЂ”');
    $allergies   = clean($d['med_allergies']   ?? 'РќРµРјР°С”');
    $conditions  = clean($d['med_conditions']  ?? 'РќРµРјР°С”');
    $medications = clean($d['med_medications'] ?? 'РќРµРјР°С”');
    $diet        = clean($d['med_diet']        ?? 'РќРµРјР°С”');

    // в”Ђв”Ђ Р—Р±РµСЂРµР¶РµРЅРЅСЏ РІ Р±Р°Р·Сѓ РґР°РЅРёС… (SQLite) в”Ђв”Ђ
    try {
        $db = new PDO('sqlite:' . __DIR__ . '/admin/db/skycamp.sqlite');
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $db->prepare("INSERT INTO bookings (child_name, child_age, parent_name, phone, email, program, date) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$childName, $childAge, $parentName, $parentPhone, $parentEmail, $program, $dates]);
    } catch (Exception $e) {
        // Р†РіРЅРѕСЂСѓС”РјРѕ РїРѕРјРёР»РєРё Р‘Р”, С‰РѕР± РЅРµ Р·Р»Р°РјР°С‚Рё РІС–РґРїСЂР°РІРєСѓ email
    }

    $subject = "рџЏ•пёЏ РќРѕРІР° Р·Р°СЏРІРєР° #{$bookingId} вЂ” {$childName}";
    $body    = buildBookingEmail($bookingId, $childName, $program, $dates, $price,
                                 $parentName, $parentEmail, $parentPhone, $parentPhone2,
                                 $childDob, $childAge, $allergies, $conditions, $medications, $diet);

    $headers = buildHeaders($parentEmail, $parentName);
    $sent    = mail(ADMIN_EMAIL, '=?UTF-8?B?' . base64_encode($subject) . '?=', $body, $headers);

    // Підтвердження батькам
    $confirmSubject = '🏕️ Ваша заявка до Sky Camp отримана';
    $confirmBody    = buildConfirmEmail($childName, $program, $dates, $bookingId);
    $confirmHeaders = buildHeaders(ADMIN_EMAIL, SITE_NAME);
    mail($parentEmail, '=?UTF-8?B?' . base64_encode($confirmSubject) . '?=', $confirmBody, $confirmHeaders);

    // Telegram
    $tgText = "🏕️ <b>НОВЕ БРОНЮВАННЯ</b>\n\n";
    $tgText .= "🆔 <b>{$bookingId}</b>\n";
    $tgText .= "📋 <b>Програма:</b> {$program}\n";
    $tgText .= "👶 <b>Учасник:</b> {$childName} ({$childAge})\n";
    $tgText .= "👤 <b>Батьки:</b> {$parentName}\n";
    $tgText .= "📞 <b>Телефон:</b> {$parentPhone}\n";
    sendTelegramMessage($tgText);

    if ($sent) {
        echo json_encode(['ok' => true, 'bookingId' => $bookingId]);
    } else {
        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => 'РџРѕРјРёР»РєР° РІС–РґРїСЂР°РІРєРё. Р—Р°С‚РµР»РµС„РѕРЅСѓР№С‚Рµ РЅР°Рј РЅР°РїСЂСЏРјСѓ.']);
    }
}

// в•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђ
// РљРћРќРўРђРљРўРќРђ Р¤РћР РњРђ
// в•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђ
function handleContact(array $d): void {
    if (empty($d['name']) || empty($d['email']) || empty($d['message'])) {
        http_response_code(422);
        echo json_encode(['ok' => false, 'error' => "Р—Р°РїРѕРІРЅС–С‚СЊ СѓСЃС– РѕР±РѕРІ'СЏР·РєРѕРІС– РїРѕР»СЏ"]);
        exit;
    }
    if (!filter_var($d['email'], FILTER_VALIDATE_EMAIL)) {
        http_response_code(422);
        echo json_encode(['ok' => false, 'error' => 'РќРµРІС–СЂРЅРёР№ С„РѕСЂРјР°С‚ email']);
        exit;
    }

    $name    = clean($d['name']);
    $email   = clean($d['email']);
    $subject = clean($d['subject'] ?? 'Р—Р°РіР°Р»СЊРЅРёР№ Р·Р°РїРёС‚');
    $message = clean($d['message']);

    // в”Ђв”Ђ Р—Р±РµСЂРµР¶РµРЅРЅСЏ РІ Р±Р°Р·Сѓ РґР°РЅРёС… (SQLite) в”Ђв”Ђ
    try {
        $db = new PDO('sqlite:' . __DIR__ . '/admin/db/skycamp.sqlite');
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $db->prepare("INSERT INTO messages (name, email, message) VALUES (?, ?, ?)");
        $stmt->execute([$name, $email, $message]);
    } catch (Exception $e) {
        // Р†РіРЅРѕСЂСѓС”РјРѕ РїРѕРјРёР»РєРё Р‘Р”
    }

    $emailSubject = "вњ‰пёЏ РџРѕРІС–РґРѕРјР»РµРЅРЅСЏ РІС–Рґ {$name} вЂ” Sky Camp";
    $body = <<<HTML
<html><head><meta charset="utf-8"></head><body style="font-family:Arial,sans-serif;color:#222;max-width:600px;margin:0 auto">
<div style="background:#005daa;padding:20px 24px;border-radius:8px 8px 0 0">
  <h2 style="color:#fff;margin:0;font-size:20px">вњ‰пёЏ РќРѕРІРµ РїРѕРІС–РґРѕРјР»РµРЅРЅСЏ Р· СЃР°Р№С‚Сѓ</h2>
</div>
<div style="background:#f8f9ff;padding:24px;border-radius:0 0 8px 8px;border:1px solid #dce9ff">
  <table style="width:100%;border-collapse:collapse">
    <tr><td style="padding:8px 0;color:#666;width:140px"><b>Р†Рј'СЏ</b></td><td style="padding:8px 0">{$name}</td></tr>
    <tr><td style="padding:8px 0;color:#666"><b>Email</b></td><td style="padding:8px 0"><a href="mailto:{$email}">{$email}</a></td></tr>
    <tr><td style="padding:8px 0;color:#666"><b>РўРµРјР°</b></td><td style="padding:8px 0">{$subject}</td></tr>
    <tr><td style="padding:8px 0;color:#666;vertical-align:top"><b>РџРѕРІС–РґРѕРјР»РµРЅРЅСЏ</b></td><td style="padding:8px 0">{$message}</td></tr>
  </table>
</div>
<p style="text-align:center;color:#999;font-size:12px;margin-top:16px">В© 2026 Sky Camp вЂ” <a href="https://sky-camp.pp.ua">sky-camp.pp.ua</a></p>
</body></html>
HTML;

    $headers = buildHeaders($email, $name);
    $sent    = mail(ADMIN_EMAIL, '=?UTF-8?B?' . base64_encode($emailSubject) . '?=', $body, $headers);

    // Telegram
    $tgText = "📩 <b>НОВЕ ЗВЕРНЕННЯ</b>\n\n";
    $tgText .= "👤 <b>Від:</b> {$name}\n";
    $tgText .= "📧 <b>Email:</b> {$email}\n";
    $tgText .= "💬 <b>Повідомлення:</b>\n" . mb_substr($message, 0, 500) . (mb_strlen($message) > 500 ? '...' : '');
    sendTelegramMessage($tgText);

    if ($sent) {
        echo json_encode(['ok' => true]);
    } else {
        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => 'РџРѕРјРёР»РєР° РІС–РґРїСЂР°РІРєРё. РЎРїСЂРѕР±СѓР№С‚Рµ РїС–Р·РЅС–С€Рµ.']);
    }
}

// в•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђ
// EMAIL TEMPLATES
// в•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђ
function buildBookingEmail(string $bookingId, string $childName, string $program, string $dates,
                            string $price, string $parentName, string $parentEmail,
                            string $parentPhone, string $parentPhone2,
                            string $childDob, string $childAge,
                            string $allergies, string $conditions, string $medications, string $diet): string {
    return <<<HTML
<html><head><meta charset="utf-8"></head><body style="font-family:Arial,sans-serif;color:#222;max-width:640px;margin:0 auto">
<div style="background:linear-gradient(135deg,#005daa,#008eff);padding:24px;border-radius:12px 12px 0 0">
  <h2 style="color:#fff;margin:0;font-size:22px">рџЏ•пёЏ РќРћР’Рђ Р—РђРЇР’РљРђ РќРђ РўРђР‘Р†Р </h2>
  <p style="color:rgba(255,255,255,.8);margin:6px 0 0;font-size:14px">РќРѕРјРµСЂ Р·Р°СЏРІРєРё: <strong style="color:#fff">#{$bookingId}</strong></p>
</div>
<div style="background:#f8f9ff;padding:24px;border:1px solid #dce9ff;border-top:none">

  <h3 style="color:#005daa;margin:0 0 12px;font-size:16px;border-bottom:2px solid #dce9ff;padding-bottom:8px">рџ“‹ РџСЂРѕРіСЂР°РјР°</h3>
  <table style="width:100%;border-collapse:collapse;margin-bottom:20px">
    <tr><td style="padding:6px 0;color:#666;width:160px"><b>РџСЂРѕРіСЂР°РјР°</b></td><td style="padding:6px 0">{$program}</td></tr>
    <tr><td style="padding:6px 0;color:#666"><b>Р”Р°С‚Рё</b></td><td style="padding:6px 0">{$dates}</td></tr>
    <tr><td style="padding:6px 0;color:#666"><b>Р’Р°СЂС‚С–СЃС‚СЊ</b></td><td style="padding:6px 0;font-size:18px;font-weight:bold;color:#005daa">{$price}</td></tr>
  </table>

  <h3 style="color:#005daa;margin:0 0 12px;font-size:16px;border-bottom:2px solid #dce9ff;padding-bottom:8px">рџ‘¶ РЈС‡Р°СЃРЅРёРє</h3>
  <table style="width:100%;border-collapse:collapse;margin-bottom:20px">
    <tr><td style="padding:6px 0;color:#666;width:160px"><b>Р†Рј'СЏ</b></td><td style="padding:6px 0">{$childName}</td></tr>
    <tr><td style="padding:6px 0;color:#666"><b>Р”Р°С‚Р° РЅР°СЂРѕРґР¶РµРЅРЅСЏ</b></td><td style="padding:6px 0">{$childDob}</td></tr>
    <tr><td style="padding:6px 0;color:#666"><b>Р’С–РєРѕРІР° РіСЂСѓРїР°</b></td><td style="padding:6px 0">{$childAge}</td></tr>
  </table>

  <h3 style="color:#005daa;margin:0 0 12px;font-size:16px;border-bottom:2px solid #dce9ff;padding-bottom:8px">рџ‘ЁвЂЌрџ‘©вЂЌрџ‘§ Р‘Р°С‚СЊРєРё</h3>
  <table style="width:100%;border-collapse:collapse;margin-bottom:20px">
    <tr><td style="padding:6px 0;color:#666;width:160px"><b>РџР†Р‘</b></td><td style="padding:6px 0">{$parentName}</td></tr>
    <tr><td style="padding:6px 0;color:#666"><b>Email</b></td><td style="padding:6px 0"><a href="mailto:{$parentEmail}">{$parentEmail}</a></td></tr>
    <tr><td style="padding:6px 0;color:#666"><b>РўРµР»РµС„РѕРЅ</b></td><td style="padding:6px 0">{$parentPhone}</td></tr>
    <tr><td style="padding:6px 0;color:#666"><b>Р”РѕРґР°С‚РєРѕРІРёР№ С‚РµР».</b></td><td style="padding:6px 0">{$parentPhone2}</td></tr>
  </table>

  <h3 style="color:#ba1a1a;margin:0 0 12px;font-size:16px;border-bottom:2px solid #ffdad6;padding-bottom:8px">рџЏҐ РњРµРґРёС‡РЅР° С–РЅС„РѕСЂРјР°С†С–СЏ</h3>
  <table style="width:100%;border-collapse:collapse;background:#fff8f7;border-radius:8px;padding:12px">
    <tr><td style="padding:6px 8px;color:#666;width:160px"><b>РђР»РµСЂРіС–С—</b></td><td style="padding:6px 8px">{$allergies}</td></tr>
    <tr><td style="padding:6px 8px;color:#666"><b>Р—Р°С…РІРѕСЂСЋРІР°РЅРЅСЏ</b></td><td style="padding:6px 8px">{$conditions}</td></tr>
    <tr><td style="padding:6px 8px;color:#666"><b>Р›С–РєРё</b></td><td style="padding:6px 8px">{$medications}</td></tr>
    <tr><td style="padding:6px 8px;color:#666"><b>Р”С–С”С‚Р°</b></td><td style="padding:6px 8px">{$diet}</td></tr>
  </table>

</div>
<p style="text-align:center;color:#999;font-size:12px;margin-top:16px">В© 2026 Sky Camp вЂ” <a href="https://sky-camp.pp.ua">sky-camp.pp.ua</a></p>
</body></html>
HTML;
}

function buildConfirmEmail(string $childName, string $program, string $dates, string $bookingId): string {
    return <<<HTML
<html><head><meta charset="utf-8"></head><body style="font-family:Arial,sans-serif;color:#222;max-width:600px;margin:0 auto">
<div style="background:linear-gradient(135deg,#005daa,#008eff);padding:32px 24px;border-radius:12px 12px 0 0;text-align:center">
  <div style="font-size:48px;margin-bottom:12px">рџЏ•пёЏ</div>
  <h2 style="color:#fff;margin:0;font-size:24px">Р—Р°СЏРІРєСѓ РѕС‚СЂРёРјР°РЅРѕ!</h2>
  <p style="color:rgba(255,255,255,.85);margin:8px 0 0">Р”СЏРєСѓС”РјРѕ Р·Р° СЂРµС”СЃС‚СЂР°С†С–СЋ РІ Sky Camp</p>
</div>
<div style="background:#f8f9ff;padding:24px;border:1px solid #dce9ff;border-top:none;border-radius:0 0 12px 12px">
  <p style="font-size:16px;line-height:1.6">Р’С–С‚Р°С”РјРѕ! Р’Р°С€Р° Р·Р°СЏРІРєР° РЅР° СѓС‡Р°СЃС‚СЊ <strong>{$childName}</strong> Сѓ С‚Р°Р±РѕСЂС– РѕС‚СЂРёРјР°РЅР° С‚Р° РѕР±СЂРѕР±Р»СЏС”С‚СЊСЃСЏ. РњРё Р·РІ'СЏР¶РµРјРѕСЃСЏ Р· РІР°РјРё РїСЂРѕС‚СЏРіРѕРј <strong>24 РіРѕРґРёРЅ</strong>.</p>

  <div style="background:#fff;border:2px solid #005daa;border-radius:8px;padding:16px;margin:20px 0;text-align:center">
    <p style="color:#666;margin:0 0 4px;font-size:13px">РќРѕРјРµСЂ РІР°С€РѕС— Р·Р°СЏРІРєРё</p>
    <p style="color:#005daa;font-size:24px;font-weight:bold;margin:0">#{$bookingId}</p>
  </div>

  <table style="width:100%;border-collapse:collapse;margin:16px 0">
    <tr><td style="padding:8px 0;color:#666;width:120px"><b>РџСЂРѕРіСЂР°РјР°</b></td><td style="padding:8px 0">{$program}</td></tr>
    <tr><td style="padding:8px 0;color:#666"><b>Р”Р°С‚Рё</b></td><td style="padding:8px 0">{$dates}</td></tr>
    <tr><td style="padding:8px 0;color:#666"><b>РЈС‡Р°СЃРЅРёРє</b></td><td style="padding:8px 0">{$childName}</td></tr>
  </table>

  <p style="background:#e8f4fd;border-radius:8px;padding:12px 16px;font-size:14px;color:#005daa;margin:16px 0">
    рџ“‹ РџС–СЃР»СЏ РїС–РґС‚РІРµСЂРґР¶РµРЅРЅСЏ Р·Р°СЏРІРєРё РјРё РЅР°РґС–С€Р»РµРјРѕ РІР°Рј РґРµС‚Р°Р»СЊРЅСѓ С–РЅС„РѕСЂРјР°С†С–СЋ РїСЂРѕ РїС–РґРіРѕС‚РѕРІРєСѓ РґРѕ С‚Р°Р±РѕСЂСѓ С‚Р° СЂРµРєРІС–Р·РёС‚Рё РґР»СЏ РѕРїР»Р°С‚Рё.
  </p>

  <div style="text-align:center;margin-top:24px">
    <a href="https://sky-camp.pp.ua" style="background:#005daa;color:#fff;padding:12px 28px;border-radius:24px;text-decoration:none;font-weight:600;font-size:15px">РџРѕРІРµСЂРЅСѓС‚РёСЃСЊ РЅР° СЃР°Р№С‚</a>
  </div>
</div>
<p style="text-align:center;color:#999;font-size:12px;margin-top:16px">В© 2026 Sky Camp вЂ” <a href="https://sky-camp.pp.ua" style="color:#005daa">sky-camp.pp.ua</a></p>
</body></html>
HTML;
}

// в”Ђв”Ђ Email Headers в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ
function buildHeaders(string $replyEmail, string $replyName): string {
    $boundary = md5(uniqid('boundary', true));
    return implode("\r\n", [
        'MIME-Version: 1.0',
        'Content-Type: text/html; charset=UTF-8',
        'Content-Transfer-Encoding: base64',
        'From: =?UTF-8?B?' . base64_encode(SITE_NAME) . '?= <noreply@sky-camp.pp.ua>',
        'Reply-To: =?UTF-8?B?' . base64_encode($replyName) . '?= <' . $replyEmail . '>',
        'X-Mailer: PHP/' . phpversion(),
        'X-Priority: 1',
    ]);
}
